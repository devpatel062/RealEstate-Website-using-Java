package project.beans;

public class Product {
	         
}
